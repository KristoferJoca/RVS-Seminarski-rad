﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class FormaAktivnostUnosKlasa
    {
        // atributi
        private string _stringKonekcije;
        private string _sifra;
        private string _tipAktivnosti;
        private string _opis;

        // property
        public string Sifra
        {
            get { return _sifra; }
            set { _sifra = value; }
        }

        public string TipAktivnosti
        {
            get { return _tipAktivnosti; }
            set { _tipAktivnosti = value; }
        }

        public string Opis
        {
            get { return _opis; }
            set { _opis = value; }
        }

        public FormaAktivnostUnosKlasa(string noviStringKonekcije)
        {
            _stringKonekcije = noviStringKonekcije;
        }

        public bool SnimiPodatke()
        {
            bool uspehSnimanja = false;

            SPAktivnostDBKlasa AktivnostDBObjekat = new SPAktivnostDBKlasa(this._stringKonekcije);
            AktivnostKlasa AktivnostObjekat = new AktivnostKlasa();
            AktivnostObjekat.Sifra = this._sifra;
            AktivnostObjekat.TipAktivnosti = this._tipAktivnosti;
            AktivnostObjekat.Opis = this._opis;
            uspehSnimanja = AktivnostDBObjekat.SnimiNovuAktivnost(AktivnostObjekat);

            return uspehSnimanja;

        }




        }
}
