﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;
using PoslovnaLogika;

namespace PrezentacionaLogika
{
    public class FormaPutanjaUnosKlasa
    {
        // atributi
        private string _stringKonekcije;
        private string _putanjaId; // string je zbog vodece nule koja je moguca u JMBG broju
        private string _naziv;
        private string _tezina;
        private string _duzina;
        private string _trajanjePutanje;
        private string _nazivAktivnosti;

        // property
        public string PutanjaId
        {
            get { return _putanjaId; }
            set { _putanjaId = value; }
        }
        
        public string Naziv
        {
            get { return _naziv; }
            set { _naziv = value; }
        }
        
        public string Tezina
        {
            get { return _tezina; }
            set { _tezina = value; }
        }

        public string Duzina
        {
            get { return _duzina; }
            set { _duzina = value; }
        }

        public string TrajanjePutanje
        {
            get { return _trajanjePutanje; }
            set { _trajanjePutanje = value; }
        }

        public string NazivAktivnosti
        {
            get { return _nazivAktivnosti; }
            set { _nazivAktivnosti = value; }
        }
        
        // konstruktor
        public FormaPutanjaUnosKlasa(string noviStringKonekcije)
        {
            _stringKonekcije = noviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaCombo()
        {
            DataSet PodaciDataSet = new DataSet();
            SPAktivnostDBKlasa AktivnostDBObjekat = new SPAktivnostDBKlasa(this._stringKonekcije);
            PodaciDataSet = AktivnostDBObjekat.DajSveAktivnosti() ; 
            return PodaciDataSet;
        }

        public bool DaLiJeSvePopunjeno()
        {
            bool svePopunjeno = false;

            if (this._nazivAktivnosti.Equals("Izaberite..."))
            {
                svePopunjeno = false;
            }
            else
            {
                if ((this._putanjaId.Length > 0) && (this._naziv.Length > 0) && (this._tezina.Length > 0) && (this._duzina.Length > 0) && (this._trajanjePutanje.Length > 0) && (this._nazivAktivnosti.Length > 0))
                {
                    svePopunjeno = true;
                }
                else
                {
                    svePopunjeno = false;
                }
            }          

            return svePopunjeno;
        }


        public bool DaLiJeJedinstvenZapis()
        {
            bool jedinstvenZapis = false;
            DataSet PodaciDataSet = new DataSet();
            SPPutanjaDBKlasa SPPutanjaDBObjekat = new SPPutanjaDBKlasa(this._stringKonekcije);
            PodaciDataSet = SPPutanjaDBObjekat.DajPutanjuPoTrajanjuPutanje(this._putanjaId);
            
            if (PodaciDataSet.Tables[0].Rows.Count == 0)
            {
                jedinstvenZapis = true;
            }
            else
            {
                jedinstvenZapis = false;
            }

            return jedinstvenZapis;

        }

        public bool DaLiSuPodaciUskladjeniSaPoslovnimPravilima()
        {
            // POSLOVNO PRAVILO:
            // na ruti u kanjoningu ne moze biti vise aktivnosti u odredjenoj putanji          
            //  nego sto je dozvoljeno maksimalnim brojem prema sistematizaciji dostupnih aktivnosti
          

            bool uskladjeniPodaci = false;

            // klasa poslovne logike
            BrojAktivnostiKlasa ZaposljavanjeObjekat = new BrojAktivnostiKlasa(this._stringKonekcije);
                        
            uskladjeniPodaci = ZaposljavanjeObjekat.DaLiImaMestaZaAktivnost(this._nazivAktivnosti);

            return uskladjeniPodaci;
        }

        public string SnimiPodatke()
        {
            string porukaUspehaSnimanja="";
            bool uspehSnimanja = false;

            // 1. provera popunjenosti
            bool SvePopunjeno = this.DaLiJeSvePopunjeno();
            if (SvePopunjeno==true) {
                porukaUspehaSnimanja = "Sve je popunjeno!";
             }
            else
            {
                porukaUspehaSnimanja = "NIJE SVE POPUNJENO!";
                return porukaUspehaSnimanja;
            }

            // 2. provera ispravnosti - karakteri, vrednost iz domena, jedinstvenost zapisa
            bool JedinstvenZapis = this.DaLiJeJedinstvenZapis();
            if (JedinstvenZapis==true)
            {
                porukaUspehaSnimanja = porukaUspehaSnimanja + "Jeste jedinstven zapis!";
            }
            else
            {
                porukaUspehaSnimanja = porukaUspehaSnimanja + "NIJE JEDINSTVEN ZAPIS!";
                return porukaUspehaSnimanja;
            }

            // 3. provera ispravnosti - provera uskladjenosti podataka sa poslovnim pravilima
            bool UskladjenoSaPoslovnimPravilima = this.DaLiSuPodaciUskladjeniSaPoslovnimPravilima();

            if (UskladjenoSaPoslovnimPravilima==true)
             {
                porukaUspehaSnimanja = porukaUspehaSnimanja + "Jeste uskladjeno sa poslovnim pravilima!";
            }
            else
            {
               porukaUspehaSnimanja = porukaUspehaSnimanja + "PODACI NISU USKLADJENI SA POSLOVNIM PRAVILIMA - ogranicenje broja Aktivnosti  u odnosu na sistematizaciju Aktivnosti!";
               return porukaUspehaSnimanja;
            }
            
            if ((SvePopunjeno==true) && (JedinstvenZapis==true) && (UskladjenoSaPoslovnimPravilima==true)){
                SPPutanjaDBKlasa objPutanjaDB = new SPPutanjaDBKlasa(_stringKonekcije);

                PutanjaKlasa PutanjaObjekat = new PutanjaKlasa();
                PutanjaObjekat.PutanjaId = _putanjaId; // nije dobro sto je PutanjaID integer, jer moze poceti sa nula
                PutanjaObjekat.Naziv = _naziv;
                PutanjaObjekat.Tezina = _tezina;
                PutanjaObjekat.Duzina = _duzina;
                PutanjaObjekat.TrajanjePutanje = _trajanjePutanje;
                

                AktivnostKlasa AktivnostObjekat = new AktivnostKlasa();

                SPAktivnostDBKlasa SPAktivnostDBObjekat = new SPAktivnostDBKlasa(_stringKonekcije);
                AktivnostObjekat.Sifra = SPAktivnostDBObjekat.DajSifruAktivnostiPoNazivu(_nazivAktivnosti);
                AktivnostObjekat.TipAktivnosti = _nazivAktivnosti;

                PutanjaObjekat.Aktivnost = AktivnostObjekat;

                uspehSnimanja = objPutanjaDB.SnimiNovuPutanju(PutanjaObjekat);
                if (uspehSnimanja)
                {
                    porukaUspehaSnimanja = porukaUspehaSnimanja +  "Uspesno snimljeni novi podaci!";
                }
                else
                {
                    porukaUspehaSnimanja = porukaUspehaSnimanja + "GRESKA SNIMANJA PODATAKA!";
                }
                return porukaUspehaSnimanja;
            }
            else
            {
                return "NEUSPEH SNIMANJA!";
            }
            
        }

        
    }
}
