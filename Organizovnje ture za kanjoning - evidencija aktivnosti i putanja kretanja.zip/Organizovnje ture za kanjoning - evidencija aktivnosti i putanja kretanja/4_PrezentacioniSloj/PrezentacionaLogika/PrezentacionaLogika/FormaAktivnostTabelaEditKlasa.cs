﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class FormaAktivnostTabelaEditKlasa
    {
        // atributi
        private string _stringKonekcije;

        // property

        // konstruktor
        public FormaAktivnostTabelaEditKlasa(string noviStringKonekcije)
        {
            _stringKonekcije = noviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaGrid(string filter)
        {
            DataSet PodaciDataSet = new DataSet();
            SPAktivnostDBKlasa SPAktivnostDBObjekat = new SPAktivnostDBKlasa(_stringKonekcije);            
            if (filter.Equals(""))
            {
                PodaciDataSet = SPAktivnostDBObjekat.DajSveAktivnosti(); 
            }
            else
            {
                PodaciDataSet = SPAktivnostDBObjekat.DajAktivnostiPoNazivu(filter); 
            }
            return PodaciDataSet;
        }
    }
}
