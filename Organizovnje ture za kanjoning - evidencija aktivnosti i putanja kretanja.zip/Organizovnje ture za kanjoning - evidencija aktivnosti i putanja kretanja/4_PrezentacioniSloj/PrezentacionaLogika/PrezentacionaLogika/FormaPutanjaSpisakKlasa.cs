﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class FormaPutanjaSpisakKlasa
    {
        // atributi
        private string _stringKonekcije;

        // property

        // konstruktor
        public FormaPutanjaSpisakKlasa(string noviStringKonekcije)
        {
            _stringKonekcije = noviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaGrid(string filter)
        {
            DataSet PodaciDataSet = new DataSet();
            SPPutanjaDBKlasa objPutanjaDB = new SPPutanjaDBKlasa(_stringKonekcije);
            if (filter.Equals(""))
            {
                PodaciDataSet = objPutanjaDB.DajSvePutanje(); 
            }
            else
            {
                PodaciDataSet = objPutanjaDB.DajPutanjuPoNazivu(filter);
            }
            return PodaciDataSet;
        }

    }
}
