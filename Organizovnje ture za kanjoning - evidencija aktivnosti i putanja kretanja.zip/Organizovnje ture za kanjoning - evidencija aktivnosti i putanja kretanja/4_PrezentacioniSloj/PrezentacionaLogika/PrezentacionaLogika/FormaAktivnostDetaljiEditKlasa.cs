﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using KlasePodataka;

namespace PrezentacionaLogika
{
    public class FormaAktivnostDetaljiEditKlasa
    {
   // atributi i property
        private string _stringKonekcije;
        private SPAktivnostDBKlasa SPAktivnostDBObjekat;

        private AktivnostKlasa preuzetaAktivnostObjekat;
        private AktivnostKlasa izmenjenaAktivnostObjekat;

        private string _sifraPreuzeteAktivnosti;
        private string _nazivPreuzeteAktivnosti;
        private string _opisPreuzeteAktivnosti;

        private string _sifraIzmenjeneAktivnosti;
        private string _nazivIzmenjeneAktivnosti;
        private string _opisIzmenjeneAktivnosti;

        // PROPERTY

        public string SifraPreuzeteAktivnosti
        {
            get { return _sifraPreuzeteAktivnosti; }
            set { _sifraPreuzeteAktivnosti = value; _nazivPreuzeteAktivnosti = DajNaziv(_sifraPreuzeteAktivnosti); }
        }

        public string NazivPreuzeteAktivnosti
        {
            get { return _nazivPreuzeteAktivnosti; }
            // OVO NECEMO DA OMOGUCIMO, JER SE RACUNA IZ SIFRE set { pNazivPreuzeteAktivnosti = value; }
        }

        public string OpisPreuzeteAktivnosti
        {
            get { return _opisPreuzeteAktivnosti; }
            // OVO NECEMO DA OMOGUCIMO, JER SE RACUNA IZ SIFRE set { pNazivPreuzeteAktivnosti = value; }
        }

        public string SifraIzmenjeneAktivnosti
        {
            get { return _sifraIzmenjeneAktivnosti; }
            set { _sifraIzmenjeneAktivnosti = value; }
        }


        public string NazivIzmenjeneAktivnosti
        {
            get { return _nazivIzmenjeneAktivnosti; }
            set { _nazivIzmenjeneAktivnosti = value; }
        }

        public string OpisIzmenjeneAktivnosti
        {
            get { return _opisIzmenjeneAktivnosti; }
            set { _opisIzmenjeneAktivnosti = value; }
        }


        // konstruktor
        public FormaAktivnostDetaljiEditKlasa(string noviStringKonekcije)
        {
            _stringKonekcije = noviStringKonekcije;
            SPAktivnostDBObjekat = new SPAktivnostDBKlasa(_stringKonekcije);
        }

        // privatne metode
        private string DajNaziv(string pomSifra)
        {
            string pomNaziv ="";
            DataSet PodaciDataSet = new DataSet();
            pomNaziv = SPAktivnostDBObjekat.DajNazivPremaAktivnostId(pomSifra); 

            return pomNaziv;
        }

        // javne metode
        public bool ObrisiAktivnost()
        {
            // Aktivnost koja je trenutno u atributima dato, TJ. preuzeta sifra je bitna
            bool uspehBrisanja = false;
            uspehBrisanja = SPAktivnostDBObjekat.ObrisiAktivnost(_sifraPreuzeteAktivnosti);  

            return uspehBrisanja;

        }

        public bool IzmeniAktivnost()
        {
            bool uspehIzmene = false;
            preuzetaAktivnostObjekat = new AktivnostKlasa();
            izmenjenaAktivnostObjekat = new AktivnostKlasa();

            preuzetaAktivnostObjekat.Sifra = _sifraPreuzeteAktivnosti;
            preuzetaAktivnostObjekat.TipAktivnosti = _nazivPreuzeteAktivnosti;
            preuzetaAktivnostObjekat.Opis = _opisPreuzeteAktivnosti;

            izmenjenaAktivnostObjekat.Sifra = _sifraIzmenjeneAktivnosti;
            izmenjenaAktivnostObjekat.TipAktivnosti = _nazivIzmenjeneAktivnosti;
            izmenjenaAktivnostObjekat.Opis = _opisIzmenjeneAktivnosti;

            uspehIzmene = SPAktivnostDBObjekat.IzmeniAktivnost(preuzetaAktivnostObjekat, izmenjenaAktivnostObjekat);  

            return uspehIzmene;
        }
    }
}
