﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using System.Data;
using System.Configuration;
using PrezentacionaLogika;

namespace KorisnickiInterfejs
{
    public partial class PutanjaSpisak : System.Web.UI.Page
    {
        // atributi
        private FormaPutanjaSpisakKlasa FormaPutanjaSpisakObjekat;

        // konstruktor


        // nase metode
        private void NapuniGrid(DataSet ds)
        {
            // povezivanje grida sa datasetom
            PutanjeGridView.DataSource = ds.Tables[0];
            PutanjeGridView.DataBind();
        }

      
         
        // dogadjaji
        protected void Page_Load(object sender, EventArgs e)
        {
            FormaPutanjaSpisakObjekat = new FormaPutanjaSpisakKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ConnectionString);  
        }

        protected void FiltrirajButton_Click(object sender, EventArgs e)
        {
            NapuniGrid(FormaPutanjaSpisakObjekat.DajPodatkeZaGrid(FilterTextBox.Text));
        }

        protected void SviButton_Click(object sender, EventArgs e)
        {
            NapuniGrid(FormaPutanjaSpisakObjekat.DajPodatkeZaGrid(""));
        }
    }
}