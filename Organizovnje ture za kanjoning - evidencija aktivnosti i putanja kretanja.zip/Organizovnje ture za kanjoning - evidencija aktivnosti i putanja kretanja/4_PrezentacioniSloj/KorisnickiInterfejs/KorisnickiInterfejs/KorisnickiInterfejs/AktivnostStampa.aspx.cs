﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using System.Data;
using PrezentacionaLogika;
using System.Configuration; 

namespace KorisnickiInterfejs
{
    public partial class AktivnostStampa : System.Web.UI.Page
    {
        // atributi

        // nase metode
        private void NapuniGrid(DataSet noviPodaciDataSet)
        {
            // povezivanje grida sa datasetom
            SpisakAktivnostiGridView.DataSource = noviPodaciDataSet.Tables[0];
            SpisakAktivnostiGridView.DataBind();
        }
        
                
        protected void Page_Load(object sender, EventArgs e)
        {
            string filterVrednost = "";
            FormaAktivnostStampaKlasa objFormaAktivnostStampa = new FormaAktivnostStampaKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ConnectionString);

            try
            {
                if (Request.QueryString["filter"].ToString() != null)
                {
                    filterVrednost = Request.QueryString["filter"].ToString();
                }
                

                if ((filterVrednost.Equals("")) || (filterVrednost==null) || (filterVrednost == "0")) {
                    NaslovLabel.Text = "SPISAK SVIH AKTIVNOSTI";
                }
                else
                {
                    NaslovLabel.Text = "FILTRIRANI SPISAK AKTIVNOSTI, tipAktivnosti=" + filterVrednost;
                }

               
            }catch (Exception greska)
            {
                NaslovLabel.Text = "SPISAK SVIH AKTIVNOSTI";
            }
            string parametarZaFilter = "";
            if (filterVrednost == "0") 
            { parametarZaFilter = "";
            }
            else
            {
                parametarZaFilter = filterVrednost;
            }
            NapuniGrid(objFormaAktivnostStampa.DajPodatkeZaGrid(parametarZaFilter));

        }
    }
}