﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using DBUtils;
using System.Configuration;
using PrezentacionaLogika;

namespace KorisnickiInterfejs
{
    public partial class AktivnostUnos : System.Web.UI.Page
    {
        // atributi
        private FormaAktivnostUnosKlasa FormaAktivnostiUnosObjekat;

        private void IsprazniKontrole()
        {
            SifraTextBox.Text = "";
            TipAktivnostiTextBox.Text = "";
            OpisTextBox.Text = "";
        }



            protected void Page_Load(object sender, EventArgs e)
        {
            FormaAktivnostiUnosObjekat = new FormaAktivnostUnosKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ConnectionString);
        }
                       
        protected void OdustaniButton_Click(object sender, EventArgs e)
        {
            IsprazniKontrole();
        }

        protected void SnimiButton_Click(object sender, EventArgs e)
        {
            bool uspehSnimanja = false;

            FormaAktivnostiUnosObjekat.Sifra = SifraTextBox.Text;
            FormaAktivnostiUnosObjekat.TipAktivnosti = TipAktivnostiTextBox.Text;
            FormaAktivnostiUnosObjekat.Opis = OpisTextBox.Text;
            uspehSnimanja = FormaAktivnostiUnosObjekat.SnimiPodatke();
            if (uspehSnimanja)
            {
                StatusLabel.Text = "Uspesno snimljeni podaci!";
            }
            else
            {
                StatusLabel.Text = "Problem snimanja podataka!";
            }
            
        }
    }
}