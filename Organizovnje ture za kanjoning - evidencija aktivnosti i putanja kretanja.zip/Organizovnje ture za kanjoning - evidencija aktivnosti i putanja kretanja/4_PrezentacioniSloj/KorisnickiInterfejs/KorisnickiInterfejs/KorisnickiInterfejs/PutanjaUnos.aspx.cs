﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using System.Data;
using System.Configuration;
using PrezentacionaLogika;

namespace KorisnickiInterfejs
{
    public partial class PutanjaUnos : System.Web.UI.Page
    {
        // atributi
        FormaPutanjaUnosKlasa FormaPutanjakUnosObjekat; 
        
        // konstruktor


        // nase metode
        private void NapuniCombo()
        {
            // IZDVAJANJE PODATAKA IZ XML POSREDSTVOM WEB SERVISA
            DataSet AktivnostDataSet = new DataSet();
            AktivnostDataSet = FormaPutanjakUnosObjekat.DajPodatkeZaCombo();

            int ukupno = AktivnostDataSet.Tables[0].Rows.Count;

            // PUNJENJE COMBO PODACIMA IZ DATASETA
            AktivnostDropDownList.Items.Add("Izaberite...");
            for (int i = 0; i < ukupno; i++)
            {
                AktivnostDropDownList.Items.Add(AktivnostDataSet.Tables[0].Rows[i].ItemArray[1].ToString());
            }

        }

        private void IsprazniKontrole()
        {
            PutanjaIdTextBox.Text = "";
            NazivTextBox.Text = "";
            TezinaTextBox.Text = "";
            DuzinaTextBox.Text = "";
            TrajanjePutanjeTextBox.Text = "";
            AktivnostDropDownList.Text ="Izaberite...";
            StatusLabel.Text = ""; 
        }

        // dogadjaji
        protected void Page_Load(object sender, EventArgs e)
        {
            FormaPutanjakUnosObjekat = new FormaPutanjaUnosKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ConnectionString);
            if (!IsPostBack)
            {
                NapuniCombo();
            }
        }

        protected void SnimiButton_Click(object sender, EventArgs e)
        {
            // ***********preuzimanje vrednosti sa korisnickog interfejsa
            // 2. nacin - preuzimaju atributi klase prezentacione logike
            FormaPutanjakUnosObjekat.PutanjaId = PutanjaIdTextBox.Text;
            FormaPutanjakUnosObjekat.Naziv = NazivTextBox.Text;
            FormaPutanjakUnosObjekat.Tezina = TezinaTextBox.Text;
            FormaPutanjakUnosObjekat.Duzina = DuzinaTextBox.Text;
            FormaPutanjakUnosObjekat.TrajanjePutanje = TrajanjePutanjeTextBox.Text;
            FormaPutanjakUnosObjekat.NazivAktivnosti = AktivnostDropDownList.Text;

            string porukaStatusaSnimanja = "";
            // *********** provera ispravnosti vrednosti
            if (AktivnostDropDownList.Text == "Izaberite...")
            {
                porukaStatusaSnimanja = "NISTE IZABRALI NAZIV AKTIVNOSTI!";
            }
            else
            {   
                try
                {
                    porukaStatusaSnimanja = FormaPutanjakUnosObjekat.SnimiPodatke();
                }
                catch (Exception greska)
                {
                    porukaStatusaSnimanja = "GRESKA:" + greska;
                }
                
            }
            StatusLabel.Text = porukaStatusaSnimanja;

        }

        protected void PonistiButton_Click(object sender, EventArgs e)
        {
            IsprazniKontrole();
        }
    }
}