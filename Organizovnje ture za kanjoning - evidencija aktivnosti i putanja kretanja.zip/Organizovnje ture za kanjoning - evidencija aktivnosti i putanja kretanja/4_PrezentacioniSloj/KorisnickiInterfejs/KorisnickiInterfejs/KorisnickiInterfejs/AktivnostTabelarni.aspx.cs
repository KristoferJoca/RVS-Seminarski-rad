﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using DBUtils;
using System.Configuration;
using System.Data;
using PrezentacionaLogika;

namespace KorisnickiInterfejs
{
    public partial class AktivnostTabelarni : System.Web.UI.Page
    {
              
        
        private void NapuniGrid(DataSet PodaciDataSet)
        {
            // povezivanje grida sa datasetom
            SpisakAktivnostiGridView.DataSource = PodaciDataSet.Tables[0];
            SpisakAktivnostiGridView.DataBind();
        }
        
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void FiltrirajButton_Click(object sender, EventArgs e)
        {
            FormaAktivnostTabelaEditKlasa FormaAktivnostTabelaEditObjekat = new FormaAktivnostTabelaEditKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ToString());
            NapuniGrid(FormaAktivnostTabelaEditObjekat.DajPodatkeZaGrid(FilterTextBox.Text));
        }

        protected void SviButton_Click(object sender, EventArgs e)
        {
            FormaAktivnostTabelaEditKlasa FormaAktivnostTabelaEditObjekat = new FormaAktivnostTabelaEditKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ToString());
            NapuniGrid(FormaAktivnostTabelaEditObjekat.DajPodatkeZaGrid(""));
        }
    }
}