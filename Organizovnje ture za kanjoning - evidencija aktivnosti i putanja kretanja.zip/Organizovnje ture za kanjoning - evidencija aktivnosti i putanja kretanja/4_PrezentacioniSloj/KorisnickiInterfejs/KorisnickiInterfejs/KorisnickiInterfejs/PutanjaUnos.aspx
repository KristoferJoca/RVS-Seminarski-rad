﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Admin.Master" AutoEventWireup="true" CodeBehind="PutanjaUnos.aspx.cs" Inherits="KorisnickiInterfejs.PutanjaUnos" %>
<asp:Content ID="Content1" ContentPlaceHolderID="HeadContent" runat="server">
    <style type="text/css">
    .style1
    {
        width: 423px;
    }
    .style2
    {
        width: 342px;
        text-align: right;
    }
    .style3
    {
        width: 423px;
        font-size: large;
    }
    .style4
    {
        font-size: large;
    }
    .style5
    {
        width: 342px;
        font-size: large;
        text-align: right;
    }
</style>
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">
    <table style="width:100%;">
    <tr>
        <td class="style5">
            &nbsp;</td>
        <td class="style3">
            <strong>UNOS Putanje</strong></td>
        <td class="style4">
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            &nbsp;</td>
        <td class="style1">
            &nbsp;</td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            <asp:Label ID="Label1" runat="server" Text="PutanjaId"></asp:Label>
        </td>
        <td class="style1">
            <asp:TextBox ID="PutanjaIdTextBox" runat="server" MaxLength="13"></asp:TextBox>
        </td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            <asp:Label ID="Label2" runat="server" Text="Naziv"></asp:Label>
        </td>
        <td class="style1">
            <asp:TextBox ID="NazivTextBox" runat="server"></asp:TextBox>
        </td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            <asp:Label ID="Label3" runat="server" Text="Tezina"></asp:Label>
        </td>
        <td class="style1">
            <asp:TextBox ID="TezinaTextBox" runat="server"></asp:TextBox>
        </td>
        <td>
            &nbsp;</td>
    </tr>
          <tr>
        <td class="style2">
            <asp:Label ID="Label5" runat="server" Text="Duzina"></asp:Label>
        </td>
        <td class="style1">
            <asp:TextBox ID="DuzinaTextBox" runat="server"></asp:TextBox>
        </td>
        <td>
            &nbsp;</td>
    </tr>
          <tr>
        <td class="style2">
            <asp:Label ID="Label6" runat="server" Text="TrajanjePutanje"></asp:Label>
        </td>
        <td class="style1">
            <asp:TextBox ID="TrajanjePutanjeTextBox" runat="server"></asp:TextBox>
        </td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            <asp:Label ID="Label4" runat="server" Text="Aktivnost"></asp:Label>
        </td>
        <td class="style1">
            <asp:DropDownList ID="AktivnostDropDownList" runat="server" Height="16px" Width="233px">
            </asp:DropDownList>
        </td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            &nbsp;</td>
        <td class="style1">
            &nbsp;</td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            &nbsp;</td>
        <td class="style1">
            <asp:Label ID="StatusLabel" runat="server" Text="STATUS"></asp:Label>
        </td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            &nbsp;</td>
        <td class="style1">
            <asp:Button ID="SnimiButton" runat="server" Text="SNIMI" Width="69px" 
                onclick="SnimiButton_Click" />
            <asp:Button ID="btnPonisti" runat="server" Text="PONISTI" 
                onclick="PonistiButton_Click" />
        </td>
        <td>
            &nbsp;</td>
    </tr>
    <tr>
        <td class="style2">
            &nbsp;</td>
        <td class="style1">
            &nbsp;</td>
        <td>
            &nbsp;</td>
    </tr>
</table>
</asp:Content>
