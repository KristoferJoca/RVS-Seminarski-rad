﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using System.Data;
using PrezentacionaLogika;
using System.Configuration; 

namespace KorisnickiInterfejs
{
    public partial class AktivnostTabelaEdit : System.Web.UI.Page
    {
        
        // nase metode
        private void NapuniGrid(DataSet ds)
        {
            // povezivanje grida sa datasetom
            SpisakAktivnostiEditGridView.DataSource = ds.Tables[0];
            SpisakAktivnostiEditGridView.DataBind();
        }
        
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                FormaAktivnostTabelaEditKlasa FormaAktivnostTabelaEditObjekat = new FormaAktivnostTabelaEditKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ConnectionString);
                NapuniGrid(FormaAktivnostTabelaEditObjekat.DajPodatkeZaGrid(""));
            }
        }
                
        protected void SpisakAktivnostiEditGridView_SelectedIndexChanged(object sender, EventArgs e)
        {
            Response.Redirect("AktivnostDetaljiEdit.aspx?Sifra=" + SpisakAktivnostiEditGridView.Rows[SpisakAktivnostiEditGridView.SelectedIndex].Cells[1].Text);
        }
    }
}