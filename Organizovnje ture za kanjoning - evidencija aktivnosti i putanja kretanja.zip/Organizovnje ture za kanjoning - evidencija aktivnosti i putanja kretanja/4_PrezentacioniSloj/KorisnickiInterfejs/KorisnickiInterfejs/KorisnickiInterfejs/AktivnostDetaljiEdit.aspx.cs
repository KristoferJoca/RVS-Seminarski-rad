﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using System.Data;
using PrezentacionaLogika;
using System.Configuration; 

namespace KorisnickiInterfejs
{
    public partial class AktivnostDetaljiEdit : System.Web.UI.Page
    {
        // atributi
        private string _sifra = "";
        FormaAktivnostDetaljiEditKlasa FormaAktivnostDetaljiEditObjekat; 

        // nase metode
        private void IsprazniKontrole()
        {
            SifraTextBox.Text = "";
            NazivTextBox.Text = "";
            OpisTextBox.Text = "";

        }

        private void AktivirajKontrole()
        {
            SifraTextBox.Enabled = true;
            NazivTextBox.Enabled = true;
            OpisTextBox.Enabled = true;
        }

        private void DeaktivirajKontrole()
        {
            SifraTextBox.Enabled = false ;
            NazivTextBox.Enabled = false;
            OpisTextBox.Enabled = false;
        }

        private void PrikaziPodatke(FormaAktivnostDetaljiEditKlasa FormaAktivnostDetaljiEditObjekat)
        {
            // podacima stranice upravlja klasa prezentacione logike, zato se uzimaju iz nje za prikaz
            SifraTextBox.Text = FormaAktivnostDetaljiEditObjekat.SifraPreuzeteAktivnosti;
            NazivTextBox.Text = FormaAktivnostDetaljiEditObjekat.NazivPreuzeteAktivnosti;
            OpisTextBox.Text = FormaAktivnostDetaljiEditObjekat.OpisPreuzeteAktivnosti;

        }

        // dogadjaji
        protected void Page_Load(object sender, EventArgs e)
        {
            FormaAktivnostDetaljiEditObjekat = new FormaAktivnostDetaljiEditKlasa(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ConnectionString);
            _sifra = Request.QueryString["Sifra"].ToString();
            FormaAktivnostDetaljiEditObjekat.SifraPreuzeteAktivnosti = _sifra;
            // OVDE SE NE DOBIJA NAZIV SPOLJA, VEC SE IZRACUNAVA NAZIV na set svojstvu property za sifru UNUTAR KLASE  
            if (!IsPostBack)
            {
                PrikaziPodatke(FormaAktivnostDetaljiEditObjekat);
            }  
        }
                
        protected void ObrisiButton_Click(object sender, EventArgs e)
        {
            FormaAktivnostDetaljiEditObjekat.SifraPreuzeteAktivnosti= SifraTextBox.Text;
            bool uspehBrisanja = FormaAktivnostDetaljiEditObjekat.ObrisiAktivnost();
            if (uspehBrisanja)
            {
                StatusLabel.Text = "Uspesno obrisan zapis!";
                IsprazniKontrole();
            }
            else
            {
                StatusLabel.Text = "NEUSPEH BRISANJA zapisa!";
            }
        }

        protected void IzmeniButton_Click(object sender, EventArgs e)
        {
            // PREUZIMANJE POCETNIH, STARIH VREDNOSTI - OVDE NEMA POTREBE JER SE URADI NA PAGE LOAD
            //objFormaAktivnostDetaljiEdit.SifraPreuzeteAktivnosti = txbSifra.Text;
            // - ovo se izracuna iz sifre, pa se ne moze ni dodeliti: objFormaAktivnostDetaljiEdit.NazivPreuzeteAktivnosti = txbNaziv.Text; 
            AktivirajKontrole();
            SifraTextBox.Focus();
        }

        protected void SnimiIzmenuButton_Click(object sender, EventArgs e)
        {
            FormaAktivnostDetaljiEditObjekat.SifraIzmenjeneAktivnosti = SifraTextBox.Text;
            FormaAktivnostDetaljiEditObjekat.NazivIzmenjeneAktivnosti = NazivTextBox.Text;
            FormaAktivnostDetaljiEditObjekat.OpisIzmenjeneAktivnosti = OpisTextBox.Text;
            bool uspehIzmene = FormaAktivnostDetaljiEditObjekat.IzmeniAktivnost();
            if (uspehIzmene)
            {
                StatusLabel.Text = "Uspesno izmenjen zapis!";
                IsprazniKontrole();
            }
            else
            {
                StatusLabel.Text = "NEUSPEH BRISANJA zapisa!";
            }
            DeaktivirajKontrole();
        }
    }
}