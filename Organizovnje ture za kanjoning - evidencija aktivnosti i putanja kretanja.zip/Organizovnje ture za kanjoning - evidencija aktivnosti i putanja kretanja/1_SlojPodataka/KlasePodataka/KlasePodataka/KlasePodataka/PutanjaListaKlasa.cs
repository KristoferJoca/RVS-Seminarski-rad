﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class PutanjaListaKlasa
    {

        // atributi
        private List<PutanjaKlasa> _listaPutanja; 

        // property
        public List<PutanjaKlasa> ListaPutanja
        {
            get
            {
                return _listaPutanja;
            }
            set
            {
                if (this._listaPutanja != value)
                    this._listaPutanja = value;
            }
        }

        // konstruktor
        public PutanjaListaKlasa()
        {
            _listaPutanja = new List<PutanjaKlasa>(); 

        }

        // privatne metode

        // javne metode
        public void DodajElementListe(PutanjaKlasa novaPutanjaObjekat)
        {
            _listaPutanja.Add(novaPutanjaObjekat);
        }

        public void ObrisiElementListe(PutanjaKlasa putanjaObjekatZaBrisanje)
        {
            _listaPutanja.Remove(putanjaObjekatZaBrisanje);  
        }

        public void ObrisiElementNaPoziciji(int pozicija)
        {
            _listaPutanja.RemoveAt(pozicija);
        }

        public void IzmeniElementListe(PutanjaKlasa staraPutanjaObjekat, PutanjaKlasa novaPutanjaObjekat)
        {
            int indexStarePutanje = 0;
            indexStarePutanje = _listaPutanja.IndexOf(staraPutanjaObjekat);
            _listaPutanja.RemoveAt(indexStarePutanje);
            _listaPutanja.Insert(indexStarePutanje, novaPutanjaObjekat);   
        }

           
    }
}
