﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Data;
using System.Data.SqlClient;

namespace KlasePodataka
{
    public class SPPutanjaDBKlasa
    {
        // atributi
        private string _stringKonekcije;

        // property
        // 1. nacin
        public string StringKonekcije
        {
            get
            {
                return _stringKonekcije;
            }
        }
        // konstruktor
        // 2. nacin prijema vrednosti stringa konekcije spolja i dodele atributu
        public SPPutanjaDBKlasa(string noviStringKonekcije)
        // OVO JE DOBRO JER OBAVEZUJE DA SE PRILIKOM INSTANCIRANJA OVE KLASE
        // MORA OBEZBEDITI STRING KONEKCIJE
        {
            _stringKonekcije = noviStringKonekcije; 
        }

        // privatne metode

        // javne metode
        public DataSet DajSvePutanje()
        {
            // MOGU biti jos neke procedure, mogu SE VRATITI VREDNOSTI I U LISTU, DATA TABLE...
            DataSet PodaciDataSet = new DataSet();

            SqlConnection pomKonekcija = new SqlConnection(_stringKonekcije);
            pomKonekcija.Open();
            SqlCommand pomKomanda = new SqlCommand("DajSvePutanjeSaJoin", pomKonekcija);
            pomKomanda.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = pomKomanda;
            adapter.Fill(PodaciDataSet);
            pomKonekcija.Close();
            pomKonekcija.Dispose();
            
            return PodaciDataSet;
        }

        public DataSet DajPutanjuPoNazivu(string nazivFilter)
        {
            // MOGU biti jos neke procedure, mogu SE VRATITI VREDNOSTI I U LISTU, DATA TABLE...
            DataSet PodaciDataSet = new DataSet();

            SqlConnection pomKonekcija = new SqlConnection(_stringKonekcije);
            pomKonekcija.Open();
            SqlCommand pomKomanda = new SqlCommand("DajPutanjuPoNazivu", pomKonekcija);
            pomKomanda.CommandType = CommandType.StoredProcedure;
            pomKomanda.Parameters.Add("@PutanjaNaziv", SqlDbType.NVarChar).Value = nazivFilter;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = pomKomanda;
            adapter.Fill(PodaciDataSet);
            pomKonekcija.Close();
            pomKonekcija.Dispose();

            return PodaciDataSet;
        }


        public DataSet DajPutanjuPoTrajanjuPutanje(string TrajanjePutanjeFilter)
        {
            // MOGU biti jos neke procedure, mogu SE VRATITI VREDNOSTI I U LISTU, DATA TABLE...
            DataSet PodaciDataSet = new DataSet();

            SqlConnection pomKonekcija = new SqlConnection(_stringKonekcije);
            pomKonekcija.Open();
            SqlCommand pomKomanda = new SqlCommand("DajPutanjuPoTrajanju", pomKonekcija);
            pomKomanda.CommandType = CommandType.StoredProcedure;
            pomKomanda.Parameters.Add("@PutanjaTrajanje", SqlDbType.NVarChar).Value = TrajanjePutanjeFilter;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = pomKomanda;
            adapter.Fill(PodaciDataSet);
            pomKonekcija.Close();
            pomKonekcija.Dispose();

            return PodaciDataSet;
        }

        public int DajUkupnoPutanjaZaAktivnosti(string AktivnostIdFilter)
        {
            int ukupnoPutanja=0;
            DataSet PodaciDataSet = new DataSet();
            SqlConnection pomKonekcija = new SqlConnection(_stringKonekcije);
            pomKonekcija.Open();
            SqlCommand pomKomanda = new SqlCommand("DajBrojAktivnostiPremaSifri", pomKonekcija); 
            pomKomanda.CommandType = CommandType.StoredProcedure;
            pomKomanda.Parameters.Add("@SifraAktivnosti", SqlDbType.NVarChar).Value = AktivnostIdFilter;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = pomKomanda;
            adapter.Fill(PodaciDataSet);
            pomKonekcija.Close();
            pomKonekcija.Dispose();
            ukupnoPutanja = int.Parse(PodaciDataSet.Tables[0].Rows[0].ItemArray[0].ToString());  
            return ukupnoPutanja;
        } 


        private PutanjaListaKlasa DajListuSvihPutanja()
        {
            // PRIPREMA PROMENLJIVIH
            PutanjaListaKlasa putanjaListaObjekat = new PutanjaListaKlasa();
            DataSet podaciDataSetPutanja = new DataSet();
            PutanjaKlasa PutanjaObjekat;
            AktivnostKlasa AktivnostObjekat;

            SqlConnection pomKonekcija = new SqlConnection(_stringKonekcije);
            pomKonekcija.Open();
            SqlCommand pomKomanda = new SqlCommand("DajSvePutanjeeSaJoinSifromAktivnosti", pomKonekcija); 
            pomKomanda.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter adapter = new SqlDataAdapter();
            adapter.SelectCommand = pomKomanda;
            adapter.Fill(podaciDataSetPutanja);
            pomKonekcija.Close();
            pomKonekcija.Dispose();

            // FORMIRANJE OBJEKATA I UBACIVANJE U LISTU
            for (int brojac = 0; brojac < podaciDataSetPutanja.Tables[0].Rows.Count; brojac++)
            {
                AktivnostObjekat = new AktivnostKlasa();
                AktivnostObjekat.Sifra = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray[4].ToString();
                AktivnostObjekat.TipAktivnosti = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray[3].ToString();
                AktivnostObjekat.Opis = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray[3].ToString();

                PutanjaObjekat = new PutanjaKlasa();
                PutanjaObjekat.PutanjaId = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray [0].ToString ();
                PutanjaObjekat.Naziv = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray [0].ToString ();
                PutanjaObjekat.Tezina = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray [0].ToString ();
                PutanjaObjekat.Duzina = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray[0].ToString();
                PutanjaObjekat.TrajanjePutanje = podaciDataSetPutanja.Tables[0].Rows[brojac].ItemArray[0].ToString();
                PutanjaObjekat.Aktivnost = AktivnostObjekat;
                putanjaListaObjekat.DodajElementListe (PutanjaObjekat);
            }

            return putanjaListaObjekat;
        }
        

        public bool SnimiNovuPutanju(PutanjaKlasa novaPutanjaObjekat)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova =0;

            SqlConnection pompomKonekcija = new SqlConnection(_stringKonekcije);
            pompomKonekcija.Open();

            SqlCommand pompomKomanda = new SqlCommand("DodajNovuPutanju", pompomKonekcija);
            pompomKomanda.CommandType = CommandType.StoredProcedure;
            pompomKomanda.Parameters.Add("@PutanjaId", SqlDbType.NVarChar).Value = novaPutanjaObjekat.PutanjaId;
            pompomKomanda.Parameters.Add("@Naziv", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Naziv;
            pompomKomanda.Parameters.Add("@Tezina", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Tezina;
            pompomKomanda.Parameters.Add("@Duzina", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Duzina;
            pompomKomanda.Parameters.Add("@TrajanjePutanje", SqlDbType.NVarChar).Value = novaPutanjaObjekat.TrajanjePutanje;
            pompomKomanda.Parameters.Add("@AktivnostId", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Aktivnost.Sifra;

            brojSlogova = pompomKomanda.ExecuteNonQuery();
            pompomKonekcija.Close();
            pompomKonekcija.Dispose();
     
            // 2. varijanta
            return (brojSlogova > 0);

        }

        public bool ObrisiPutanju(string PutanjaIdZaBrisanje)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova = 0;
            // 1. varijanta - skolska 
            //bool uspehSnimanja= false;

            SqlConnection pomKonekcija = new SqlConnection(_stringKonekcije);
            pomKonekcija.Open();

            SqlCommand pomKomanda = new SqlCommand("ObrisiPutanju", pomKonekcija);
            pomKomanda.CommandType = CommandType.StoredProcedure;
            pomKomanda.Parameters.Add("@PutanjaId", SqlDbType.NVarChar).Value = PutanjaIdZaBrisanje;
            brojSlogova = pomKomanda.ExecuteNonQuery();
            pomKonekcija.Close();
            pomKonekcija.Dispose();

            return (brojSlogova > 0);

        }

        public bool IzmeniPutanju(PutanjaKlasa staraPutanjaObjekat, PutanjaKlasa novaPutanjaObjekat)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova = 0;
            // 1. varijanta - skolska 
            //bool uspehSnimanja= false;

            SqlConnection pomKonekcija = new SqlConnection(_stringKonekcije);
            pomKonekcija.Open();

            SqlCommand pomKomanda = new SqlCommand("IzmeniPutanju", pomKonekcija);
            pomKomanda.CommandType = CommandType.StoredProcedure;
            pomKomanda.Parameters.Add("@StariPutanjaId", SqlDbType.NVarChar).Value = staraPutanjaObjekat.PutanjaId;
            pomKomanda.Parameters.Add("@PutanjaId", SqlDbType.NVarChar).Value = novaPutanjaObjekat.PutanjaId;
            pomKomanda.Parameters.Add("@Naziv", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Naziv;
            pomKomanda.Parameters.Add("@Tezina", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Tezina;
            pomKomanda.Parameters.Add("@Duzina", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Duzina;
            pomKomanda.Parameters.Add("@TrajanjePutanje", SqlDbType.NVarChar).Value = novaPutanjaObjekat.TrajanjePutanje;
            pomKomanda.Parameters.Add("@AktivnostId", SqlDbType.NVarChar).Value = novaPutanjaObjekat.Aktivnost.Sifra;
            brojSlogova = pomKomanda.ExecuteNonQuery();
            pomKonekcija.Close();
            pomKonekcija.Dispose();

            return (brojSlogova > 0);

        }

        


    }
}
