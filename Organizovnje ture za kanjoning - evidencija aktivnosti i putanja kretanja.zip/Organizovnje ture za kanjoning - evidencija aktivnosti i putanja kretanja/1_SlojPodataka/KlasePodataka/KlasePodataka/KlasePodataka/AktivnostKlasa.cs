﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class AktivnostKlasa
    {
        // atributi
        private string _sifra;
        private string _tipAktivnosti;
        private string _opis;

        // property
        public string Sifra
        {
            get
            {
                return _sifra;
            }
            set
            {
                if (this._sifra != value)
                    this._sifra = value;
            }
        }

        public string TipAktivnosti
        {
            get
            {
                return _tipAktivnosti;
            }
            set
            {
                if (this._tipAktivnosti != value)
                    this._tipAktivnosti = value;
            }
        }

        public string Opis
        {
            get
            {
                return _opis;
            }
            set
            {
                if (this._opis != value)
                    this._opis = value;
            }
        }

        // konstruktor
        public AktivnostKlasa()
        {
            _sifra = "";
            _tipAktivnosti = "";
            _opis = "";
        }

        
    }
}
