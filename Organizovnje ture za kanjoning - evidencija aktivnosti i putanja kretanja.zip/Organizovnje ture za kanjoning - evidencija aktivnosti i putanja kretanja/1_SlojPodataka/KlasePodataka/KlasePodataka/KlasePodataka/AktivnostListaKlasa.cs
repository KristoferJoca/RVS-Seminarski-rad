﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class AktivnostListaKlasa
    {
        // atributi
        private List<AktivnostKlasa> _listaAktivnosti; 

        // property
        public List<AktivnostKlasa> ListaAktivnosti
        {
            get
            {
                return _listaAktivnosti;
            }
            set
            {
                if (this._listaAktivnosti != value)
                    this._listaAktivnosti = value;
            }
        }

        // konstruktor
        public AktivnostListaKlasa()
        {
            _listaAktivnosti = new List<AktivnostKlasa>(); 

        }

        // privatne metode

        // javne metode
        public void DodajElementListe(AktivnostKlasa novaAktivnostObjekat)
        {
            _listaAktivnosti.Add(novaAktivnostObjekat);
        }

        public void ObrisiElementListe(AktivnostKlasa aktivnostObjekatZaBrisanje)
        {
            _listaAktivnosti.Remove(aktivnostObjekatZaBrisanje);  
        }

        public void ObrisiElementNaPoziciji(int pozicija)
        {
            _listaAktivnosti.RemoveAt(pozicija);
        }

        public void IzmeniElementListe(AktivnostKlasa staraAktivnostObjekat, AktivnostKlasa novaAktivnostObjekat)
        {
            int indexStareAktivnosti = 0;
            indexStareAktivnosti = _listaAktivnosti.IndexOf(staraAktivnostObjekat);
            _listaAktivnosti.RemoveAt(indexStareAktivnosti);
            _listaAktivnosti.Insert(indexStareAktivnosti, novaAktivnostObjekat);   
        }

           

     




    }
}
