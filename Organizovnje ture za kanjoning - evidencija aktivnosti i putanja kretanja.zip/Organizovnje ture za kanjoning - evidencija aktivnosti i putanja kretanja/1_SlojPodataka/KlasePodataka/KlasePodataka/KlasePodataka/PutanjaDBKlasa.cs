﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using DBUtils;
using System.Data;

namespace KlasePodataka
{
    public class PutanjaDBKlasa: TabelaKlasa
    {
        

        public PutanjaDBKlasa(KonekcijaKlasa novaKonekcija, string noviNazivTabele):base(novaKonekcija, noviNazivTabele)
        {
            
        }
        
        
        public DataSet DajSvePutanje()
        {
            return this.DajPodatke("select * from Putanja");
        }

        public bool DodajNovuPutanju(PutanjaKlasa noviPutanjaObjekat)
        {
            string upit="insert into Putanja values('" + noviPutanjaObjekat.PutanjaId + "', '" + noviPutanjaObjekat.Naziv + "','" + noviPutanjaObjekat.Tezina + "','" + noviPutanjaObjekat.Duzina + "','" + noviPutanjaObjekat.TrajanjePutanje + "','" + noviPutanjaObjekat.Aktivnost.Sifra + "')";
            return this.IzvrsiAzuriranje(upit);

        }
    }
}
