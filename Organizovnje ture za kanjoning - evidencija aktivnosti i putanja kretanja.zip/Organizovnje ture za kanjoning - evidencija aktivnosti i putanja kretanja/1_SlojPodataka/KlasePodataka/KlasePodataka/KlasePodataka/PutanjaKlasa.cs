﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class PutanjaKlasa
    {
        // atributi
        private string _PutanjaId;
        private string _Naziv;
        private string _Tezina;
        private string _Duzina;
        private string _TrajanjePutanje;
        private AktivnostKlasa _AktivnostObjekat;

        // property
        public string PutanjaId
        {
            get { return _PutanjaId; }
            set { _PutanjaId = value; }
        }

        

        public string Naziv
        {
            get { return _Naziv; }
            set { _Naziv = value; }
        }

        

        public string Tezina
        {
            get { return _Tezina; }
            set { _Tezina = value; }
        }
        public string Duzina
        {
            get { return _Duzina; }
            set { _Duzina = value; }
        }
        public string TrajanjePutanje
        {
            get { return _TrajanjePutanje; }
            set { _TrajanjePutanje = value; }
        }


        public AktivnostKlasa Aktivnost
        {
            get { return _AktivnostObjekat; }
            set { _AktivnostObjekat = value; }
        }
    }
}
