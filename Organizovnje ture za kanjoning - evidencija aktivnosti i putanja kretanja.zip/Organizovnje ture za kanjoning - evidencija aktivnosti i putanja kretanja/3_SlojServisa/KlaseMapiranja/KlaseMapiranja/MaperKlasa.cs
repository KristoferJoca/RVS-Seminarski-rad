﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using KlasePodataka;

namespace KlaseMapiranja
{
    public class MaperKlasa
    {
        // atributi
        private string pStringKonekcije;

        // property

        // konstruktor
        public MaperKlasa(string noviStringKonekcije)
        {
            pStringKonekcije = noviStringKonekcije;
        }
        public string DajSifruAktivnostiZaWebServis(string NazivAktivnostiIzBazePodatakaParametar)
        {
            string pomAktivnostIdWS = "";

            // OVO JE HEURISTIKA:
            // prvo slovo naziva je to sifra u drugom sistemu
            // DAKLE: sifra Aktivnosti za web servis je prvo slovo naziva Aktivnosti, znaci za pauzu je "p"
            pomAktivnostIdWS = NazivAktivnostiIzBazePodatakaParametar[0].ToString();

            return pomAktivnostIdWS;

        }

    }
}
