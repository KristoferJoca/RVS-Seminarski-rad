﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using KlasePodataka;
using KlaseMapiranja;


namespace PoslovnaLogika
{
    public class BrojAktivnostiKlasa
    {
        // TREBALO BI DA SE PRERADI IZ 3 KLASE:
        // Sistematizacija Aktivnosti - izdvaja ogranicenje
        // Opterecenje - stanje u BP povodom broja Aktivnosti
        // Zaposljavanje - proverava i uporedjuje podatke iz sistematizacije i opterecenja
        
        // atributi
        private string _stringKonekcije;

        // property

        // konstruktor
        public BrojAktivnostiKlasa(string NoviStringKonekcije)
        {
            _stringKonekcije = NoviStringKonekcije;
        }

        // privatne metode

        // public metode

        public int KolikoImaTrenutnoAktivnosti(string NazivAktivnostiIzBazePodatakaParametar)
        {
            // ################################################################
            //izracunavanje ID Aktivnosti
            SPAktivnostDBKlasa SPAktivnostDBObjekat = new SPAktivnostDBKlasa(_stringKonekcije);
            string AktivnostIdIzBazePodataka = SPAktivnostDBObjekat.DajSifruAktivnostiPoNazivu(NazivAktivnostiIzBazePodatakaParametar);

            // ################################################################
            // IZRACUNAVANJE TRENUTNOG BROJA Putanja U BAZI PODATAKA U ODNOSU NA SIFRU AKTIVNOSTI DodajNovuAktivnost
            // 
            OpterecenjeKlasa opterecenjeObjekat = new OpterecenjeKlasa(_stringKonekcije);
            return opterecenjeObjekat.DajTrenutnoOpterecenje(AktivnostIdIzBazePodataka);

        }

        public bool DaLiImaMestaZaAktivnost(string NazivAktivnostiIzBazePodatakaParametar)
        {
            // POSLOVNO PRAVILO:
            // Na Kanjoningu ne moze biti  vise Aktivnosti u odredjenoj putanji
            //  nego sto je dozvoljeno maksimalnim brojem prema Sistematizaciji
            // Aktivnosti.

            bool imaMesta = false;

            // ################################################################
            // 1. IZRACUNAVANJE TRENUTNOG BROJA Putanja U BAZI PODATAKA
            int pomUkupnoAktivnosti = this.KolikoImaTrenutnoAktivnosti(NazivAktivnostiIzBazePodatakaParametar);

            // ################################################################
            // 2. MAPIRANJE SLOJEVA - uskladjivanje ID Aktivnosti iz raznih delova programa
            // Web servis ima p - pauza, baza podataka ima 1 - pauza
            string pomAktivnostIdWS = "";
            MaperKlasa maperObjekat = new MaperKlasa(_stringKonekcije);
            pomAktivnostIdWS = maperObjekat.DajSifruAktivnostiZaWebServis(NazivAktivnostiIzBazePodatakaParametar);

            // ################################################################
            // 3. IZDVAJANJE MAX BROJ AKTIVNOSTI ZA ODG Aktivnost
            SistematizacijaKlasa sistematizacijaObjekat = new SistematizacijaKlasa();
            int pomMaxBrojAktivnosti = sistematizacijaObjekat.DajMaxBrojAktivnosti(pomAktivnostIdWS);

            // ################################################################
            // 4. UPOREDJIVANJE TRENUTNOG BROJA I MAX BROJA AKTIVNOSTI
            if (pomUkupnoAktivnosti < pomMaxBrojAktivnosti)
            {
                imaMesta = true;
            }
            else
            {
                imaMesta = false;
            }
            return imaMesta;
        }
    }
}
