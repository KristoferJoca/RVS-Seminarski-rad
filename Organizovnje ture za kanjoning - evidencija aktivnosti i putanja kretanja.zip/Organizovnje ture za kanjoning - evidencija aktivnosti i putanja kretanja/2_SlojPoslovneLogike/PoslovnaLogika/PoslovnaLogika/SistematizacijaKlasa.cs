﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PoslovnaLogika
{
    public class SistematizacijaKlasa
    {
        public int DajMaxBrojAktivnosti(String AktivnostIdWSParametar)
        {
            WSAktivnostPodaci.OgranicenjaAktivnosti objOgranicenja = new WSAktivnostPodaci.OgranicenjaAktivnosti();
            int pomMaxBrojAktivnosti = objOgranicenja.DajMaxAktivnostiPutanja(AktivnostIdWSParametar);
            return pomMaxBrojAktivnosti;
        }

    }
}
