﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using KlasePodataka;

namespace PoslovnaLogika
{
    public class OpterecenjeKlasa
    {

        private string _stringKonekcije;

        public OpterecenjeKlasa(string noviStringKonekcije)
        {
            _stringKonekcije = noviStringKonekcije;
        }

        public int DajTrenutnoOpterecenje(string AktivnostIdZaProveru)
            // izracunava iz baze podataka koliko trenutno ima Aktivnosti za datu Putanju
        {
            int pomUkupnoAktivnosti = 0;
            SPPutanjaDBKlasa SPPutanjaDBObjekat = new SPPutanjaDBKlasa(_stringKonekcije);
            
            // u slucaju da ima praznina u ID vrednosti
            string parametarZaProveru = AktivnostIdZaProveru.Replace(" ", "");

            pomUkupnoAktivnosti = SPPutanjaDBObjekat.DajUkupnoPutanjaZaAktivnosti(parametarZaProveru);            
            return pomUkupnoAktivnosti;
        }


    }
}
